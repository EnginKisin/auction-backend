import { useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSecurity } from '../context/SecurityContext';
import { escapeHtml, sanitizeUrl } from '../lib/securityUtils';

/**
 * Güvenlik middleware hook'u
 * Route koruması, input sanitization ve güvenlik kontrolleri
 */
export const useSecurityMiddleware = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, user } = useAuth();


  // Güvenli route navigation
  const secureNavigate = useCallback((path, options = {}) => {
    const sanitizedPath = sanitizeUrl(path);
    if (sanitizedPath) {
      navigate(sanitizedPath, options);
    } else {
      console.warn('Güvensiz URL:', path);
      navigate('/error?reason=invalid-url');
    }
  }, [navigate]);

  // Route koruması
  useEffect(() => {
    // Protected routes kontrolü
    const protectedRoutes = ['/dashboard', '/products', '/auctions/my'];
    const isProtectedRoute = protectedRoutes.some(route => 
      location.pathname.startsWith(route)
    );

    if (isProtectedRoute && !isAuthenticated) {
      navigate('/login?reason=unauthorized');
      return;
    }

    // Admin routes kontrolü (eğer admin sistemi varsa)
    const adminRoutes = ['/admin'];
    const isAdminRoute = adminRoutes.some(route => 
      location.pathname.startsWith(route)
    );

    if (isAdminRoute && (!isAuthenticated || !user?.isAdmin)) {
      navigate('/dashboard?reason=insufficient-permissions');
      return;
    }

  }, [location.pathname, isAuthenticated, user, navigate]);

  // Input sanitization helper
  const sanitizeInput = useCallback((input, type = 'text') => {
    if (!input) return input;

    switch (type) {
      case 'html':
        return escapeHtml(input);
      case 'url':
        return sanitizeUrl(input);
      case 'email':
        // Email format kontrolü
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(input) ? input : '';
      case 'phone':
        // Telefon format kontrolü
        const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
        return phoneRegex.test(input) ? input : '';
      default:
        return input;
    }
  }, []);

  // Form data sanitization
  const sanitizeFormData = useCallback((formData, schema = {}) => {
    const sanitized = {};
    
    Object.keys(formData).forEach(key => {
      const fieldSchema = schema[key] || {};
      const value = formData[key];
      
      if (value !== null && value !== undefined) {
        sanitized[key] = sanitizeInput(value, fieldSchema.type || 'text');
      }
    });
    
    return sanitized;
  }, [sanitizeInput]);

  // XSS koruması için innerHTML kullanımını engelle
  const safeSetInnerHTML = useCallback((element, content) => {
    if (element && content) {
      element.textContent = content; // innerHTML yerine textContent kullan
    }
  }, []);

  // URL validation
  const validateAndSanitizeUrl = useCallback((url) => {
    if (!url) return null;
    
    try {
      const sanitized = sanitizeUrl(url);
      if (sanitized) {
        return sanitized;
      }
    } catch (error) {
      console.warn('URL validation failed:', error);
    }
    
    return null;
  }, []);

  // File upload security
  const validateFileUpload = useCallback((file, options = {}) => {
    const { validateFileUpload: validateFile } = require('../lib/securityUtils');
    return validateFile(file, options);
  }, []);

  return {
    secureNavigate,
    sanitizeInput,
    sanitizeFormData,
    safeSetInnerHTML,
    validateAndSanitizeUrl,
    validateFileUpload,
  };
};
