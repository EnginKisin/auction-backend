/**
 * Güvenlik Konfigürasyonu
 * Frontend için temel güvenlik ayarları
 */

export const SECURITY_CONFIG = {
  // Session Management
  session: {
    timeout: 15 * 60 * 1000, // 15 dakika
    refreshThreshold: 5 * 60 * 1000, // 5 dakika kala uyarı
  },

  // File Upload Security
  fileUpload: {
    maxSize: 5 * 1024 * 1024, // 5MB
    allowedTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
    allowedExtensions: ['jpg', 'jpeg', 'png', 'gif', 'webp'],
  },

  // XSS Protection
  xss: {
    enabled: true,
    mode: 'sanitize',
    sanitizeOptions: {
      allowedTags: ['b', 'i', 'em', 'strong', 'a', 'br'],
      allowedAttributes: {
        'a': ['href', 'title'],
      },
    },
  },

  // Input Validation
  validation: {
    maxLength: {
      productName: 100,
      productDescription: 2000,
      userComment: 500,
      searchQuery: 100,
    },
    patterns: {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[\+]?[0-9\s\-\(\)]{10,}$/,
      url: /^https?:\/\/.+$/,
      price: /^\d+(\.\d{1,2})?$/,
    },
  },

  // Error Handling
  errorHandling: {
    showDetailedErrors: false,
    logErrors: true,
  },
};
