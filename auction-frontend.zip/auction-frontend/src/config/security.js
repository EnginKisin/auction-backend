/**
 * Güvenlik Konfigürasyonu
 * Tüm güvenlik ayarları burada merkezi olarak yönetilir
 */

export const SECURITY_CONFIG = {
  // Session Management
  session: {
    timeout: 30 * 60 * 1000, // 30 dakika
    refreshThreshold: 5 * 60 * 1000, // 5 dakika kala uyarı
    maxConcurrentSessions: 3,
  },

  // Authentication
  auth: {
    maxLoginAttempts: 5,
    lockoutDuration: 15 * 60 * 1000, // 15 dakika
    passwordMinLength: 8,
    passwordRequirements: {
      requireUppercase: true,
      requireLowercase: true,
      requireNumbers: true,
      requireSpecialChars: true,
    },
    tokenExpiry: 24 * 60 * 60 * 1000, // 24 saat
  },

  // Rate Limiting
  rateLimit: {
    api: {
      maxRequests: 100, // 1 dakikada
      timeWindow: 60000, // 1 dakika
    },
    login: {
      maxRequests: 5, // 1 dakikada
      timeWindow: 60000, // 1 dakika
    },
    fileUpload: {
      maxRequests: 10, // 1 dakikada
      timeWindow: 60000, // 1 dakika
    },
  },

  // File Upload Security
  fileUpload: {
    maxSize: 5 * 1024 * 1024, // 5MB
    allowedTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
    allowedExtensions: ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    scanForMalware: false, // Backend'de yapılmalı
    validateContent: true,
  },

  // Content Security Policy
  csp: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'", "'unsafe-inline'"],
    styleSrc: ["'self'", "'unsafe-inline'"],
    imgSrc: ["'self'", "data:", "https:"],
    connectSrc: ["'self'", "https:"],
    fontSrc: ["'self'", "https:"],
    objectSrc: ["'none'"],
    mediaSrc: ["'self'"],
    frameSrc: ["'none'"],
  },

  // XSS Protection
  xss: {
    enabled: true,
    mode: 'sanitize', // 'sanitize' veya 'block'
    sanitizeOptions: {
      allowedTags: ['b', 'i', 'em', 'strong', 'a', 'br'],
      allowedAttributes: {
        'a': ['href', 'title'],
      },
    },
  },

  // CSRF Protection
  csrf: {
    enabled: true,
    tokenLength: 32,
    headerName: 'X-CSRF-Token',
    cookieName: 'csrf-token',
  },

  // Input Validation
  validation: {
    maxLength: {
      productName: 100,
      productDescription: 2000,
      userComment: 500,
      searchQuery: 100,
    },
    patterns: {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[\+]?[0-9\s\-\(\)]{10,}$/,
      url: /^https?:\/\/.+/,
      price: /^\d+(\.\d{1,2})?$/,
    },
  },

  // Error Handling
  errorHandling: {
    showDetailedErrors: false, // Production'da false olmalı
    logErrors: true,
    reportErrors: false, // Error reporting service
  },

  // Monitoring & Logging
  monitoring: {
    logSecurityEvents: true,
    logUserActions: true,
    logApiCalls: false,
    alertOnSuspiciousActivity: true,
  },
};

// Environment-specific overrides
export const getSecurityConfig = (environment = 'development') => {
  const config = { ...SECURITY_CONFIG };

  switch (environment) {
    case 'production':
      config.errorHandling.showDetailedErrors = false;
      config.monitoring.logApiCalls = true;
      config.session.timeout = 15 * 60 * 1000; // 15 dakika
      break;
      
    case 'staging':
      config.errorHandling.showDetailedErrors = true;
      config.monitoring.logApiCalls = true;
      break;
      
    case 'development':
    default:
      config.errorHandling.showDetailedErrors = true;
      config.monitoring.logApiCalls = true;
      config.session.timeout = 60 * 60 * 1000; // 1 saat
      break;
  }

  return config;
};

// Security headers
export const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'X-XSS-Protection': '1; mode=block',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
};

// Content Security Policy string
export const getCSPString = () => {
  const csp = SECURITY_CONFIG.csp;
  return Object.entries(csp)
    .map(([key, values]) => `${key} ${values.join(' ')}`)
    .join('; ');
};
