import { useState, useEffect } from 'react'
import Modal from './Modal'
import { useToast } from '../../context/ToastContext'
import { createProduct, updateProduct, uploadProductImages, deleteProductImage } from '../../api/products'

export default function ProductModal({ 
  open, 
  product = null, 
  onClose, 
  onSuccess 
}) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: ''
  })
  const [images, setImages] = useState([])
  const [existingImages, setExistingImages] = useState([])
  const [imagesToDelete, setImagesToDelete] = useState([])
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const { success, error } = useToast()

  const isEditMode = !!(product && typeof product === 'object' && product.id)

  useEffect(() => {
    if (product && typeof product === 'object' && product.id) {
      // Düzenleme modu
      setFormData({
        name: product.name || '',
        description: product.description || '',
        price: product.price || ''
      })
      // Set existing images from product data
      const productImages = product.images || product.imageUrls || product.photos || []
      setExistingImages(productImages)
      setImagesToDelete([]) // Reset images to delete
    } else {
      // Yeni ürün ekleme modu
      setFormData({ name: '', description: '', price: '' })
      setImages([])
      setExistingImages([])
      setImagesToDelete([])
    }
  }, [product])

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files)
    setImages(prev => [...prev, ...files])
  }

  const removeNewImage = (index) => {
    setImages(prev => prev.filter((_, i) => i !== index))
  }

  const removeExistingImage = (imageId) => {
    if (!imageId) {
      error('Görsel ID bulunamadı')
      return
    }
    
    // Görseli hemen silme, sadece silinecek görseller listesine ekle
    setImagesToDelete(prev => [...prev, imageId])
    // Görseli mevcut görseller listesinden kaldır (UI'da gizle)
    setExistingImages(prev => prev.filter(img => img.id !== imageId))
    success('Görsel silinecek görseller listesine eklendi')
  }

  const handleSubmit = async () => {
    if (!formData.name.trim() || !formData.description.trim() || !formData.price) {
      error('Lütfen tüm alanları doldurun')
      return
    }

    const priceNum = Number(formData.price)
    if (isNaN(priceNum) || priceNum <= 0) {
      error('Geçerli bir fiyat girin')
      return
    }

    setLoading(true)
    try {
             if (isEditMode) {
         // Ürün güncelleme
         if (!product || !product.id) {
           error('Düzenlenecek ürün bulunamadı')
           return
         }
         
         // Önce ürün bilgilerini güncelle
         await updateProduct(product.id, {
           ...formData,
           price: priceNum
         })
         success('Ürün başarıyla güncellendi')
         
         // Ürün güncelleme başarılı olduktan sonra görsel işlemlerini yap
         setUploading(true)
         try {
           // 1. Önce silinecek görselleri sil
           if (imagesToDelete.length > 0) {
             success('Silinecek görseller işleniyor...')
             for (const imageId of imagesToDelete) {
               try {
                 await deleteProductImage(product.id, imageId)
               } catch (err) {
                 console.error('Görsel silme hatası:', err)
                 error(`Görsel silinemedi: ${err?.message || 'Bilinmeyen hata'}`)
               }
             }
             success(`${imagesToDelete.length} görsel silindi`)
           }
           
           // 2. Sonra yeni görselleri yükle
           if (images.length > 0) {
             success('Yeni görseller yükleniyor...')
             await uploadProductImages(product.id, images)
             success('Yeni görseller başarıyla yüklendi')
           }
           
           // 3. Tüm görsel işlemleri tamamlandı
           if (imagesToDelete.length > 0 || images.length > 0) {
             success('Tüm görsel işlemleri tamamlandı')
           }
         } catch (err) {
           console.error('Görsel işlemleri hatası:', err)
           error('Görsel işlemleri sırasında hata oluştu: ' + (err?.message || 'Bilinmeyen hata'))
         } finally {
           setUploading(false)
         }
       } else {
        // Yeni ürün oluşturma - sadece ürün bilgileri
        await createProduct({
          ...formData,
          price: priceNum
        })
        success('Ürün başarıyla oluşturuldu')
      }

      // Tüm işlemler başarılı olduğunda
      onSuccess()
      onClose()
    } catch (err) {
      error(err?.message || 'İşlem başarısız')
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    if (!loading && !uploading) {
      onClose()
    } else {
      // Eğer işlem devam ediyorsa kullanıcıya bilgi ver
      if (loading) {
        error('Lütfen ürün kaydedilmesini bekleyin')
      } else if (uploading) {
        error('Lütfen görseller yüklenmesini bekleyin')
      }
    }
  }

  return (
    <Modal 
      open={open} 
      title={isEditMode ? 'Ürün Düzenle' : 'Yeni Ürün Ekle'} 
      onClose={handleClose}
    >
              <div style={{ display: 'grid', gap: 16, minWidth: 400 }}>
          {/* Ürün Bilgileri */}
          <div style={{ display: 'grid', gap: 8 }}>
            <label htmlFor="name" style={{ fontWeight: '600', color: 'var(--color-accent)' }}>Ürün Adı *</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleInputChange}
              placeholder="Ürün adını girin"
              disabled={loading}
              style={{
                padding: '10px 12px',
                border: '1px solid var(--color-border)',
                borderRadius: 8,
                fontSize: '14px',
                background: 'var(--color-secondary)',
                color: 'var(--color-text)'
              }}
            />
          </div>

                                     <div style={{ display: 'grid', gap: 8 }}>
             <label htmlFor="description" style={{ fontWeight: '600', color: 'var(--color-accent)' }}>Açıklama *</label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Ürün açıklamasını girin"
              rows={3}
              disabled={loading}
              style={{ 
                resize: 'vertical',
                padding: '10px 12px',
                border: '1px solid var(--color-border)',
                borderRadius: 8,
                fontSize: '14px',
                background: 'var(--color-secondary)',
                color: 'var(--color-text)'
              }}
            />
          </div>

                                     <div style={{ display: 'grid', gap: 8 }}>
             <label htmlFor="price" style={{ fontWeight: '600', color: 'var(--color-accent)' }}>Fiyat (₺) *</label>
            <input
              id="price"
              name="price"
              type="number"
              step="0.01"
              min="0"
              value={formData.price}
              onChange={handleInputChange}
              placeholder="0.00"
              disabled={loading}
              style={{
                padding: '10px 12px',
                border: '1px solid var(--color-border)',
                borderRadius: 8,
                fontSize: '14px',
                background: 'var(--color-secondary)',
                color: 'var(--color-text)'
              }}
            />
          </div>

        {/* Görsel Yönetimi - Sadece düzenleme modunda göster */}
        {isEditMode && (
          <div style={{ display: 'grid', gap: 8 }}>
            <label style={{ fontWeight: '600', color: 'var(--color-accent)' }}>Görseller</label>
            
                         {/* Mevcut Görseller */}
             {existingImages.length > 0 && (
               <div style={{ display: 'grid', gap: 8 }}>
                 <div style={{ fontSize: '0.9em', color: 'var(--color-text-secondary)' }}>Mevcut Görseller ({existingImages.length}):</div>
                 <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(80px, 1fr))', gap: 8 }}>
                   {existingImages.filter(img => img && typeof img === 'object').map((img, index) => {
                     // Handle base64 image data like in ImageCarousel
                     const imageSrc = img.contentType && img.base64Data 
                       ? `data:${img.contentType};base64,${img.base64Data}`
                       : img.url || img.imageUrl || img.src || img.path || img
                     return (
                       <div key={img.id || `img-${index}`} style={{ position: 'relative' }}>
                         <img
                           src={imageSrc}
                           alt="Ürün görseli"
                           style={{
                             width: '100%',
                             height: 80,
                             objectFit: 'cover',
                             borderRadius: 4
                           }}
                           onError={(e) => {
                             console.error('Image failed to load:', imageSrc)
                             e.target.style.display = 'none'
                           }}
                         />
                                                  {img.id && (
                           <button
                             onClick={() => removeExistingImage(img.id)}
                             disabled={loading || uploading}
                             style={{
                               position: 'absolute',
                               top: -8,
                               right: -8,
                               background: 'var(--color-error)',
                               color: 'white',
                               border: '2px solid var(--color-secondary)',
                               borderRadius: '50%',
                               width: 24,
                               height: 24,
                               fontSize: '16px',
                               fontWeight: 'bold',
                               cursor: 'pointer',
                               display: 'flex',
                               alignItems: 'center',
                               justifyContent: 'center',
                               boxShadow: '0 2px 4px rgba(0,0,0,0.3)',
                               lineHeight: 1
                             }}
                           >
                             ×
                           </button>
                         )}
                       </div>
                     )
                   })}
                 </div>
               </div>
             )}
             
             {/* Silinecek Görseller */}
             {imagesToDelete.length > 0 && (
               <div style={{ display: 'grid', gap: 8 }}>
                 <div style={{ fontSize: '0.9em', color: 'var(--color-error)' }}>Silinecek Görseller ({imagesToDelete.length}):</div>
                 <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(80px, 1fr))', gap: 8 }}>
                   {imagesToDelete.map((imageId, index) => {
                     // Silinecek görseli bul
                     const imageToDelete = product.images?.find(img => img.id === imageId) || 
                                        product.imageUrls?.find(img => img.id === imageId) || 
                                        product.photos?.find(img => img.id === imageId)
                     
                     if (!imageToDelete) return null
                     
                     const imageSrc = imageToDelete.contentType && imageToDelete.base64Data 
                       ? `data:${imageToDelete.contentType};base64,${imageToDelete.base64Data}`
                       : imageToDelete.url || imageToDelete.imageUrl || imageToDelete.src || imageToDelete.path
                     
                     return (
                       <div key={`delete-${imageId}`} style={{ position: 'relative', opacity: 0.6 }}>
                         <img
                           src={imageSrc}
                           alt="Silinecek görsel"
                           style={{
                             width: '100%',
                             height: 80,
                             objectFit: 'cover',
                             borderRadius: 4,
                             filter: 'grayscale(50%)'
                           }}
                         />
                         <div style={{
                           position: 'absolute',
                           top: '50%',
                           left: '50%',
                           transform: 'translate(-50%, -50%)',
                           background: 'var(--color-error)',
                           color: 'white',
                           padding: '4px 8px',
                           borderRadius: 4,
                           fontSize: '12px',
                           fontWeight: 'bold'
                         }}>
                           SİLİNECEK
                         </div>
                       </div>
                     )
                   })}
                 </div>
               </div>
             )}
            
            {/* Yeni Görsel Ekleme */}
            <div style={{ display: 'grid', gap: 8 }}>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageChange}
                disabled={loading || uploading}
                style={{
                  padding: '10px 12px',
                  border: '1px solid var(--color-border)',
                  borderRadius: 8,
                  fontSize: '14px',
                  background: 'var(--color-secondary)',
                  color: 'var(--color-text)'
                }}
              />
              
              {images.length > 0 && (
                <div style={{ display: 'grid', gap: 8 }}>
                  <div style={{ fontSize: '0.9em', color: 'var(--color-text-secondary)' }}>Yeni Eklenecek Görseller:</div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(80px, 1fr))', gap: 8 }}>
                    {images.map((file, index) => (
                      <div key={index} style={{ position: 'relative' }}>
                        <img
                          src={URL.createObjectURL(file)}
                          alt={`Yeni görsel ${index + 1}`}
                          style={{
                            width: '100%',
                            height: 80,
                            objectFit: 'cover',
                            borderRadius: 4
                          }}
                        />
                                                 <button
                           onClick={() => removeNewImage(index)}
                           disabled={loading || uploading}
                           style={{
                             position: 'absolute',
                             top: -8,
                             right: -8,
                             background: 'var(--color-error)',
                             color: 'white',
                             border: '2px solid var(--color-secondary)',
                             borderRadius: '50%',
                             width: 24,
                             height: 24,
                             fontSize: '16px',
                             fontWeight: 'bold',
                             cursor: 'pointer',
                             display: 'flex',
                             alignItems: 'center',
                             justifyContent: 'center',
                             boxShadow: '0 2px 4px rgba(0,0,0,0.3)',
                             lineHeight: 1
                           }}
                         >
                           ×
                         </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Butonlar */}
        <div style={{ display: 'flex', gap: 16, justifyContent: 'center', marginTop: 24 }}>
          <button
            onClick={handleClose}
            disabled={loading || uploading}
            className="btn btn-secondary"
            style={{ padding: '12px 24px' }}
          >
            İptal
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading || uploading}
            className="btn btn-primary"
            style={{ padding: '12px 24px' }}
          >
                         {loading ? 'Ürün Kaydediliyor...' : (isEditMode && uploading) ? 'Görsel İşlemleri Yapılıyor...' : (isEditMode ? 'Güncelle' : 'Kaydet')}
          </button>
        </div>
      </div>
    </Modal>
  )
}
