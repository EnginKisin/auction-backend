export default function TimeDisplay({ time, label, showTime = true, isEndTime = false }) {
  if (!time) return null

  const formatDateTime = (dateString) => {
    try {
      const date = new Date(dateString)
      if (isNaN(date.getTime())) return dateString

      const now = new Date()
      const diffTime = now.getTime() - date.getTime()
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))

      // Eğer bitiş zamanıysa ve gelecekteyse, mutlak tarih göster
      if (isEndTime && diffTime < 0) {
        return date.toLocaleDateString('tr-TR', {
          day: 'numeric',
          month: 'long',
          year: 'numeric'
        }) + ' ' + date.toLocaleTimeString('tr-TR', {
          hour: '2-digit',
          minute: '2-digit'
        })
      }

      // Başlangıç zamanı veya geçmiş zaman için göreceli format
      let dateText
      if (diffDays === 0) {
        dateText = 'Bugün'
      } else if (diffDays === 1) {
        dateText = 'Dün'
      } else if (diffDays < 7) {
        dateText = `${diffDays} gün önce`
      } else {
        dateText = date.toLocaleDateString('tr-TR', {
          day: 'numeric',
          month: 'long',
          year: 'numeric'
        })
      }

      if (!showTime) return dateText

      const timeText = date.toLocaleTimeString('tr-TR', {
        hour: '2-digit',
        minute: '2-digit'
      })

      return `${dateText} ${timeText}`
    } catch (error) {
      return dateString
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <span style={{ fontSize: '0.875rem', color: '#6b7280' }}>{label}</span>
      <span style={{ fontWeight: 500 }}>{formatDateTime(time)}</span>
    </div>
  )
}
