export default function Modal({ open, title, children, onClose }) {
  if (!open) return null
  return (
    <div
      role="dialog"
      aria-modal="true"
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.4)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 100,
        padding: 16,
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ 
          background: 'white', 
          borderRadius: 10, 
          width: 'min(600px, 95vw)', 
          maxHeight: '90vh',
          overflow: 'auto',
          boxShadow: '0 10px 40px rgba(0,0,0,0.2)' 
        }}
      >
        <div style={{ padding: '14px 16px', borderBottom: '1px solid #eee', fontWeight: 600 }}>{title}</div>
        <div style={{ padding: 16 }}>{children}</div>
      </div>
    </div>
  )
}


