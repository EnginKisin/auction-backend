import { useEffect, useMemo, useState } from 'react'
import { listActiveAuctions, listActiveAuctionsPublic } from '../../api/auctions'
import { Link } from 'react-router-dom'
import ImageCarousel from '../components/ImageCarousel'
import CountdownTimer from '../components/CountdownTimer'

export default function HomePage() {
  const [auctions, setAuctions] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        // Try public endpoint first (no auth required)
        const data = await listActiveAuctionsPublic()
        if (mounted) setAuctions(data)
      } catch {
        // Fallback: authenticated endpoint
        try {
          const data = await listActiveAuctions()
          if (mounted) setAuctions(data)
        } catch {
          if (mounted) setAuctions([])
        }
      } finally {
        if (mounted) setLoading(false)
      }
    })()
    return () => {
      mounted = false
    }
  }, [])

  const hasItems = useMemo(() => (auctions?.length || 0) > 0, [auctions])

  return (
    <div>
      <h1>Auction</h1>
      <p>Hoş geldiniz. Giriş yaparak teklif verebilirsiniz.</p>

      <h2 style={{ marginTop: 24 }}>Aktif Açık Artırmalar</h2>
      {loading && <div>Yükleniyor...</div>}
      {!loading && !hasItems && <p>Şu anda aktif açık artırma yok.</p>}
      {!loading && hasItems && (
        <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 12 }}>
          {auctions.map((a) => (
            <li
              key={a.id}
              style={{
                border: '1px solid #e5e7eb',
                borderRadius: 8,
                padding: 12,
                display: 'grid',
                gridTemplateColumns: '240px 1fr',
                gap: 12,
                alignItems: 'center',
              }}
            >
              <div style={{ width: 240 }}>
                <ImageCarousel images={a?.product?.images || []} width={240} height={160} alt={a?.product?.name || 'Ürün'} />
              </div>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <div>
                  <div>
                    <strong>{a?.product?.name || `Açık Artırma #${a.id}`}</strong>
                  </div>
                  <div style={{ color: '#6b7280' }}>Ürün ID: {a.productId}</div>
                  <div style={{ marginTop: 6 }}>Başlangıç: ₺{Number(a.startingPrice).toLocaleString('tr-TR')}</div>
                  <div>En Yüksek Teklif: ₺{Number(a.highestBid || 0).toLocaleString('tr-TR')}</div>
                  <div style={{ marginTop: 8 }}>
                    <CountdownTimer endTime={a.endTime} startTime={a.startTime} isActive={a.isActive} />
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <Link to={`/auctions/${a.id}`}>Detay</Link>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}


