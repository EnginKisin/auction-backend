import { useEffect, useMemo, useState } from 'react'
import { getAuctionById, getAuctionByIdPublic, placeBid } from '../../../api/auctions'
import { useParams } from 'react-router-dom'
import { useAuth } from '../../../context/AuthContext'
import ImageCarousel from '../../components/ImageCarousel'
import { useToast } from '../../../context/ToastContext'

export default function AuctionDetailPage() {
  const { id } = useParams()
  const { isAuthenticated } = useAuth()
  const [auction, setAuction] = useState(null)
  const [loading, setLoading] = useState(true)
  const [amount, setAmount] = useState('')
  const [placing, setPlacing] = useState(false)
  const { success, error } = useToast()

  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        // If user is not authenticated, try public endpoint first
        const data = await (isAuthenticated ? getAuctionById(id) : getAuctionByIdPublic(id))
        if (mounted) setAuction(data)
      } finally {
        if (mounted) setLoading(false)
      }
    })()
    return () => {
      mounted = false
    }
  }, [id])

  const highest = useMemo(() => Number(auction?.highestBid || 0), [auction])
  const minNextBid = useMemo(() => {
    const base = highest > 0 ? highest : Number(auction?.startingPrice || 0)
    return base + 1
  }, [highest, auction])

  const onPlaceBid = async () => {
    const value = Number(amount)
    if (!value || value < minNextBid) return
    setPlacing(true)
    try {
      const { message } = await placeBid(id, value)
      setAuction((prev) => ({ ...prev, highestBid: value }))
      setAmount('')
      if (message) success(message)
    } catch (err) {
      error(err?.message || 'İşlem başarısız')
    } finally {
      setPlacing(false)
    }
  }

  if (loading) return <div>Yükleniyor...</div>
  if (!auction) return <div>Kayıt bulunamadı</div>

  return (
    <div style={{ maxWidth: 640 }}>
      <h2>Açık Artırma #{auction.id}</h2>
      <div style={{ margin: '12px 0' }}>
        <ImageCarousel images={auction?.product?.images || []} width={640} height={360} alt={auction?.product?.name || 'Ürün'} />
      </div>
      <div style={{ display: 'grid', gap: 8 }}>
        <div>Ürün: {auction?.product?.name || `#${auction.productId}`}</div>
        <div>Başlangıç Fiyatı: ₺{Number(auction.startingPrice).toLocaleString('tr-TR')}</div>
        <div>En Yüksek Teklif: ₺{Number(auction.highestBid || 0).toLocaleString('tr-TR')}</div>
        <div>Durum: {auction.isActive ? 'Aktif' : 'Kapalı'}</div>
        <div>Başlangıç: {auction.startTime}</div>
        <div>Bitiş: {auction.endTime}</div>
      </div>

      {auction.isActive && isAuthenticated && (
        <div style={{ marginTop: 16, display: 'flex', gap: 8, alignItems: 'center' }}>
          <input
            type="number"
            value={amount}
            min={minNextBid}
            step="0.01"
            onChange={(e) => setAmount(e.target.value)}
            placeholder={`En az ₺${minNextBid}`}
          />
          <button onClick={onPlaceBid} disabled={placing || Number(amount) < minNextBid}>
            {placing ? 'Teklif veriliyor...' : 'Teklif Ver'}
          </button>
        </div>
      )}
      {auction.isActive && !isAuthenticated && (
        <div style={{ marginTop: 16, color: '#6b7280' }}>
          Teklif vermek için giriş yapmalısınız.
        </div>
      )}
    </div>
  )
}


