import { useEffect, useMemo, useState } from 'react'
import { listMyAuctions, closeAuction } from '../../../api/auctions'
import { Link } from 'react-router-dom'
import { useToast } from '../../../context/ToastContext'

export default function MyAuctionsPage() {
  const [auctions, setAuctions] = useState([])
  const [loading, setLoading] = useState(true)
  const { success, error } = useToast()

  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        const data = await listMyAuctions()
        if (mounted) setAuctions(data)
      } finally {
        if (mounted) setLoading(false)
      }
    })()
    return () => {
      mounted = false
    }
  }, [])

  const hasItems = useMemo(() => (auctions?.length || 0) > 0, [auctions])

  const handleClose = async (id) => {
    if (!confirm('#' + id + ' ihaleyi kapatmak istiyor musunuz?')) return
    try {
      const { message } = await closeAuction(id)
      setAuctions((prev) => prev.map((a) => (a.id === id ? { ...a, isActive: false } : a)))
      if (message) success(message)
    } catch (err) {
      error(err?.message || 'İşlem başarısız')
    }
  }

  if (loading) return <div>Yükleniyor...</div>

  return (
    <div>
      <h2>İhalelerim</h2>
      {!hasItems && <p>Henüz açık artırma oluşturmadınız.</p>}
      {hasItems && (
        <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 12 }}>
          {auctions.map((a) => (
            <li key={a.id} style={{ border: '1px solid #e5e7eb', borderRadius: 8, padding: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div>
                    <strong>Açık Artırma #{a.id}</strong>
                    {!a.isActive && <span style={{ marginLeft: 8, color: '#ef4444' }}>(Kapalı)</span>}
                  </div>
                  <div style={{ color: '#6b7280' }}>Ürün ID: {a.productId}</div>
                  <div style={{ marginTop: 6 }}>Başlangıç: ₺{Number(a.startingPrice).toLocaleString('tr-TR')}</div>
                  <div>En Yüksek Teklif: ₺{Number(a.highestBid || 0).toLocaleString('tr-TR')}</div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <Link to={`/auctions/${a.id}`}>Detay</Link>
                  {a.isActive && <button onClick={() => handleClose(a.id)}>Kapat</button>}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}


