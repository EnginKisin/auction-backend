import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import ImageCarousel from '../../components/ImageCarousel'
import { listMyProducts, deleteProduct } from '../../../api/products'
import { useToast } from '../../../context/ToastContext'
import Modal from '../../components/Modal'
import ProductModal from '../../components/ProductModal'
import { createAuction } from '../../../api/auctions'

export default function ProductsPage() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()
  const { success, error } = useToast()
  const [auctionModalOpen, setAuctionModalOpen] = useState(false)
  const [productModalOpen, setProductModalOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState(null)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [durationTypeId, setDurationTypeId] = useState(1)
  const [startingPrice, setStartingPrice] = useState('')
  const [creating, setCreating] = useState(false)

  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        const items = await listMyProducts()
        if (mounted) setProducts(items)
      } finally {
        if (mounted) setLoading(false)
      }
    })()
    return () => {
      mounted = false
    }
  }, [])

  const hasProducts = useMemo(() => (products?.length || 0) > 0, [products])

  const handleDelete = async (id) => {
    if (!confirm('Ürünü silmek istediğinize emin misiniz?')) return
    try {
      const { message } = await deleteProduct(id)
      setProducts((prev) => prev.filter((p) => p.id !== id))
      if (message) success(message)
    } catch (err) {
      error(err?.message || 'İşlem başarısız')
    }
  }

  const openProductModal = (product = null) => {
    setEditingProduct(product)
    setProductModalOpen(true)
  }

  const closeProductModal = () => {
    setProductModalOpen(false)
    setEditingProduct(null)
  }

  const handleProductSuccess = () => {
    // Ürün listesini yenile
    listMyProducts().then(setProducts)
  }

  const openAuctionModal = (product) => {
    setSelectedProduct(product)
    setDurationTypeId(1)
    setStartingPrice(product?.price || '')
    setAuctionModalOpen(true)
  }

  const closeAuctionModal = () => {
    setAuctionModalOpen(false)
    setSelectedProduct(null)
  }

  const handleCreateAuction = async () => {
    if (!selectedProduct) return
    const priceNum = Number(startingPrice)
    if (!priceNum || priceNum <= 0) {
      error('Geçerli başlangıç fiyatı giriniz')
      return
    }
    setCreating(true)
    try {
      const { message } = await createAuction({ product_id: selectedProduct.id, startingPrice: priceNum, durationTypeId })
      if (message) success(message)
      closeAuctionModal()
      navigate('/auctions/my')
    } catch (err) {
      error(err?.message || 'İşlem başarısız')
    } finally {
      setCreating(false)
    }
  }

  if (loading) return <div>Yükleniyor...</div>

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>Ürünlerim</h2>
        <button 
          onClick={() => openProductModal()}
          style={{
            padding: '8px 16px',
            background: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: 6,
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          Yeni Ürün
        </button>
      </div>

      {!hasProducts && <p>Henüz ürün yok.</p>}
      {hasProducts && (
        <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'grid', gap: 12 }}>
          {products.map((p) => (
            <li
              key={p.id}
              style={{
                border: '1px solid #e5e7eb',
                borderRadius: 8,
                padding: 12,
                display: 'grid',
                gridTemplateColumns: '240px 1fr',
                gap: 12,
                alignItems: 'center',
              }}
            >
              <div style={{ width: 240, alignSelf: 'stretch', display: 'flex', alignItems: 'center' }}>
                <ImageCarousel images={p.images} width={240} height={160} alt={p.name} />
              </div>
              <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <div>
                  <strong>{p.name}</strong>
                  <div style={{ color: '#6b7280' }}>{p.description}</div>
                  <div style={{ marginTop: 6 }}>₺{Number(p.price).toLocaleString('tr-TR')}</div>
                </div>
                 <div style={{ display: 'flex', gap: 8 }}>
                  <button onClick={() => openProductModal(p)} style={{
                    padding: '6px 12px',
                    background: '#3b82f6',
                    color: 'white',
                    border: 'none',
                    borderRadius: 4,
                    cursor: 'pointer',
                    fontSize: '12px'
                  }}>Düzenle</button>
                   <button onClick={() => openAuctionModal(p)} style={{
                    padding: '6px 12px',
                    background: '#f59e0b',
                    color: 'white',
                    border: 'none',
                    borderRadius: 4,
                    cursor: 'pointer',
                    fontSize: '12px'
                  }}>Açık artırmaya aç</button>
                  <button onClick={() => handleDelete(p.id)} style={{
                    padding: '6px 12px',
                    background: '#ef4444',
                    color: 'white',
                    border: 'none',
                    borderRadius: 4,
                    cursor: 'pointer',
                    fontSize: '12px'
                  }}>Sil</button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}

      <Modal open={auctionModalOpen} title="Açık Artırma Oluştur" onClose={closeAuctionModal}>
        {selectedProduct && (
          <div style={{ display: 'grid', gap: 12 }}>
            <div style={{ color: '#374151' }}>Ürün: <strong>{selectedProduct.name}</strong></div>
            <div style={{ display: 'grid', gap: 8 }}>
              <label>Başlangıç Fiyatı</label>
              <input type="number" step="0.01" value={startingPrice} onChange={(e) => setStartingPrice(e.target.value)} />
            </div>
            <div style={{ display: 'grid', gap: 8 }}>
              <label>Süre</label>
              <select value={durationTypeId} onChange={(e) => setDurationTypeId(Number(e.target.value))}>
                <option value={1}>30 dk</option>
                <option value={2}>24 saat</option>
              </select>
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button onClick={closeAuctionModal} disabled={creating}>İptal</button>
              <button onClick={handleCreateAuction} disabled={creating}>{creating ? 'Oluşturuluyor...' : 'Oluştur'}</button>
            </div>
          </div>
        )}
      </Modal>

      {/* Ürün Ekleme/Düzenleme Modal */}
      <ProductModal
        open={productModalOpen}
        product={editingProduct}
        onClose={closeProductModal}
        onSuccess={handleProductSuccess}
      />
    </div>
  )
}


