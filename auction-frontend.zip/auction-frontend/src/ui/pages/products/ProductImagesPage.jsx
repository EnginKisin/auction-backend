import { useRef, useState } from 'react'
import { deleteProductImage, uploadProductImages } from '../../../api/products'
import { useParams } from 'react-router-dom'
import { useToast } from '../../../context/ToastContext'

export default function ProductImagesPage() {
  const { id } = useParams()
  const fileRef = useRef(null)
  const [pending, setPending] = useState(false)
  const [images, setImages] = useState([])
  const { success, error } = useToast()

  const handleUpload = async () => {
    if (!fileRef.current?.files?.length) return
    setPending(true)
    try {
      const files = Array.from(fileRef.current.files)
      const { message } = await uploadProductImages(id, files)
      // naive refresh; in a real app, fetch product images after upload
      setImages((prev) => [...prev, ...files.map((f, idx) => ({ id: Date.now() + idx, name: f.name }))])
      fileRef.current.value = ''
      if (message) success(message)
    } catch (err) {
      error(err?.message || 'İşlem başarısız')
    } finally {
      setPending(false)
    }
  }

  const handleDelete = async (imageId) => {
    try {
      const { message } = await deleteProductImage(id, imageId)
      setImages((prev) => prev.filter((i) => i.id !== imageId))
      if (message) success(message)
    } catch (err) {
      error(err?.message || 'İşlem başarısız')
    }
  }

  return (
    <div>
      <h2>Ürün Görselleri</h2>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <input ref={fileRef} type="file" multiple accept="image/*" />
        <button onClick={handleUpload} disabled={pending}>{pending ? 'Yükleniyor...' : 'Yükle'}</button>
      </div>

      <ul style={{ listStyle: 'none', padding: 0, marginTop: 16, display: 'grid', gap: 8 }}>
        {images.map((img) => (
          <li key={img.id} style={{ border: '1px solid #e5e7eb', borderRadius: 8, padding: 8, display: 'flex', justifyContent: 'space-between' }}>
            <span>{img.name || `Görsel #${img.id}`}</span>
            <button onClick={() => handleDelete(img.id)}>Sil</button>
          </li>
        ))}
      </ul>
    </div>
  )
}


