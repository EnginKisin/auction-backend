import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { createProduct, updateProduct, getMyProductById } from '../../../api/products'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { useToast } from '../../../context/ToastContext'

const schema = z.object({
  name: z.string().min(2, 'Ürün adı gerekli'),
  description: z.string().min(5, 'Açıklama gerekli'),
  price: z.coerce.number().positive('Fiyat pozitif olmalı'),
})

export default function ProductFormPage() {
  const navigate = useNavigate()
  const params = useParams()
  const location = useLocation()
  const { success, error } = useToast()
  const isEdit = Boolean(params.id)
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(schema), defaultValues: { name: '', description: '', price: '' } })

  useEffect(() => {
    let mounted = true
    ;(async () => {
      if (!isEdit) return
      // First try to get product from navigation state
      const productFromState = location.state?.product
      if (productFromState) {
        const { name, description, price } = productFromState
        if (!mounted) return
        setValue('name', name)
        setValue('description', description)
        setValue('price', price)
        return
      }
      // Fallback: fetch list and find by id
      const p = await getMyProductById(params.id)
      if (p && mounted) {
        setValue('name', p.name)
        setValue('description', p.description)
        setValue('price', p.price)
      }
    })()
    return () => {
      mounted = false
    }
  }, [isEdit, params.id, location.state, setValue])

  const onSubmit = async (values) => {
    const payload = { name: values.name, description: values.description, price: values.price }
    try {
      const { message } = isEdit
        ? await updateProduct(params.id, payload)
        : await createProduct(payload)
      if (message) success(message)
      navigate('/products', { replace: true })
    } catch (err) {
      error(err?.message || 'İşlem başarısız')
    }
  }

  return (
    <div style={{ maxWidth: 560 }}>
      <h2>{isEdit ? 'Ürünü Düzenle' : 'Yeni Ürün'}</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
          <label>Ürün Adı</label>
          <input type="text" {...register('name')} />
          {errors.name && <small style={{ color: 'tomato' }}>{errors.name.message}</small>}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
          <label>Açıklama</label>
          <textarea rows={4} {...register('description')} />
          {errors.description && <small style={{ color: 'tomato' }}>{errors.description.message}</small>}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
          <label>Fiyat</label>
          <input type="number" step="0.01" {...register('price')} />
          {errors.price && <small style={{ color: 'tomato' }}>{errors.price.message}</small>}
        </div>
        <button type="submit" disabled={isSubmitting}>{isSubmitting ? 'Kaydediliyor...' : 'Kaydet'}</button>
      </form>
    </div>
  )
}


