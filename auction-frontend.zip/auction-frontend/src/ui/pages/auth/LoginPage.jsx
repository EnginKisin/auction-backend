import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useNavigate, useLocation, Link } from 'react-router-dom'
import { useAuth } from '../../../context/AuthContext'
import { useToast } from '../../../context/ToastContext'
import { useSecurity } from '../../../context/SecurityContext'
import { useSecurityMiddleware } from '../../../hooks/useSecurityMiddleware'

const schema = z.object({
  email: z.string().email('Geçerli bir e-posta girin'),
  password: z.string().min(6, 'En az 6 karakter'),
})

export default function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const { login } = useAuth()
  const { success, error } = useToast()
  const { trackLoginAttempt, getSecurityStatus } = useSecurity()
  const { sanitizeInput } = useSecurityMiddleware()
  
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ resolver: zodResolver(schema), defaultValues: { email: '', password: '' } })

  const onSubmit = async (values) => {
    try {
      // Input sanitization
      const sanitizedEmail = sanitizeInput(values.email, 'email');
      const sanitizedPassword = sanitizeInput(values.password, 'text');
      
      await login(sanitizedEmail, sanitizedPassword)
      trackLoginAttempt(true); // Başarılı login
      success('Giriş başarılı')
      const to = location.state?.from?.pathname || '/'
      navigate(to, { replace: true })
    } catch (err) {
      trackLoginAttempt(false); // Başarısız login
      error(err?.message || 'Giriş başarısız')
    }
  }

  // Güvenlik durumu kontrolü
  const securityStatus = getSecurityStatus();
  
  return (
    <div style={{ maxWidth: 420 }}>
      <h2>Giriş Yap</h2>
      
      {/* Güvenlik uyarıları */}
      {securityStatus.isLocked && (
        <div style={{ 
          background: 'var(--color-error)', 
          color: 'white', 
          padding: '12px', 
          borderRadius: '8px', 
          marginBottom: '16px',
          textAlign: 'center'
        }}>
          Hesabınız kilitlendi. {Math.ceil(securityStatus.lockoutRemaining / 60000)} dakika bekleyin.
        </div>
      )}
      
      {securityStatus.remainingAttempts < 3 && securityStatus.remainingAttempts > 0 && (
        <div style={{ 
          background: 'var(--color-warning)', 
          color: 'white', 
          padding: '8px', 
          borderRadius: '8px', 
          marginBottom: '16px',
          textAlign: 'center',
          fontSize: '0.9em'
        }}>
          Kalan giriş denemesi: {securityStatus.remainingAttempts}
        </div>
      )}
      
      <form onSubmit={handleSubmit(onSubmit)}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
          <label>E-posta</label>
          <input type="email" {...register('email')} placeholder="email@ornek.com" />
          {errors.email && <small style={{ color: 'tomato' }}>{errors.email.message}</small>}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
          <label>Şifre</label>
          <input type="password" {...register('password')} placeholder="••••••••" />
          {errors.password && <small style={{ color: 'tomato' }}>{errors.password.message}</small>}
        </div>
        <button 
          type="submit" 
          disabled={isSubmitting || securityStatus.isLocked}
          style={{ 
            opacity: securityStatus.isLocked ? 0.5 : 1,
            cursor: securityStatus.isLocked ? 'not-allowed' : 'pointer'
          }}
        >
          {isSubmitting ? 'Giriş yapılıyor...' : securityStatus.isLocked ? 'Hesap Kilitli' : 'Giriş Yap'}
        </button>
      </form>
      <p style={{ marginTop: 12 }}>
        Hesabın yok mu? <Link to="/register">Kayıt ol</Link>
      </p>
    </div>
  )
}


