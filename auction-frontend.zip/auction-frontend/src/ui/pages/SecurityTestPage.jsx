import { useState } from 'react';
import { useSecurity } from '../../context/SecurityContext';
import { useSecurityMiddleware } from '../../hooks/useSecurityMiddleware';
import { validateFileUpload } from '../../lib/securityUtils';

export default function SecurityTestPage() {
  const [testFile, setTestFile] = useState(null);
  const [testInput, setTestInput] = useState('');
  const [testUrl, setTestUrl] = useState('');
  const [testResults, setTestResults] = useState({});
  
  const { getSecurityStatus, updateSecurityConfig } = useSecurity();
  const { sanitizeInput, sanitizeFormData, validateAndSanitizeUrl } = useSecurityMiddleware();
  
  const securityStatus = getSecurityStatus();

  const testInputSanitization = () => {
    const results = {
      original: testInput,
      sanitized: sanitizeInput(testInput, 'html'),
      url: validateAndSanitizeUrl(testUrl)
    };
    setTestResults(results);
  };

  const testFileValidation = () => {
    if (testFile) {
      const validation = validateFileUpload(testFile);
      setTestResults(prev => ({ ...prev, fileValidation: validation }));
    }
  };

  const testFormSanitization = () => {
    const testForm = {
      name: testInput,
      description: testInput,
      url: testUrl
    };
    
    const sanitized = sanitizeFormData(testForm, {
      name: { type: 'html' },
      description: { type: 'html' },
      url: { type: 'url' }
    });
    
    setTestResults(prev => ({ ...prev, formSanitization: { original: testForm, sanitized } }));
  };

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '24px' }}>
      <h2 style={{ color: 'var(--color-accent)', marginBottom: '24px' }}>Güvenlik Test Sayfası</h2>
      
      {/* Güvenlik Durumu */}
      <div style={{ 
        background: 'var(--color-secondary)', 
        padding: '16px', 
        borderRadius: '8px', 
        marginBottom: '24px',
        border: '1px solid var(--color-border)'
      }}>
        <h3 style={{ color: 'var(--color-accent)', marginBottom: '12px' }}>Güvenlik Durumu</h3>
        <div style={{ display: 'grid', gap: '8px', fontSize: '0.9em' }}>
          <div>Güvenli: {securityStatus.isSecure ? '✅' : '❌'}</div>
          <div>Kilitli: {securityStatus.isLocked ? '🔒' : '🔓'}</div>
          <div>Kalan Giriş: {securityStatus.remainingAttempts}</div>
          <div>Session Kalan: {Math.ceil(securityStatus.sessionRemaining / 60000)} dakika</div>
        </div>
      </div>

      {/* Input Sanitization Test */}
      <div style={{ 
        background: 'var(--color-secondary)', 
        padding: '16px', 
        borderRadius: '8px', 
        marginBottom: '24px',
        border: '1px solid var(--color-border)'
      }}>
        <h3 style={{ color: 'var(--color-accent)', marginBottom: '12px' }}>Input Sanitization Test</h3>
        
        <div style={{ display: 'grid', gap: '12px', marginBottom: '16px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '4px' }}>Test Input (HTML):</label>
            <input
              type="text"
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              placeholder="<script>alert('xss')</script>"
              className="secure-input"
              style={{ width: '100%', padding: '8px' }}
            />
          </div>
          
          <div>
            <label style={{ display: 'block', marginBottom: '4px' }}>Test URL:</label>
            <input
              type="text"
              value={testUrl}
              onChange={(e) => setTestUrl(e.target.value)}
              placeholder="javascript:alert('xss')"
              className="secure-input"
              style={{ width: '100%', padding: '8px' }}
            />
          </div>
        </div>
        
        <button 
          onClick={testInputSanitization}
          className="btn btn-primary"
          style={{ marginRight: '8px' }}
        >
          Test Input Sanitization
        </button>
        
        <button 
          onClick={testFormSanitization}
          className="btn btn-secondary"
        >
          Test Form Sanitization
        </button>
      </div>

      {/* File Validation Test */}
      <div style={{ 
        background: 'var(--color-secondary)', 
        padding: '16px', 
        borderRadius: '8px', 
        marginBottom: '24px',
        border: '1px solid var(--color-border)'
      }}>
        <h3 style={{ color: 'var(--color-accent)', marginBottom: '12px' }}>File Validation Test</h3>
        
        <input
          type="file"
          onChange={(e) => setTestFile(e.target.files[0])}
          accept="image/*"
          style={{ marginBottom: '12px' }}
        />
        
        <button 
          onClick={testFileValidation}
          className="btn btn-primary"
          disabled={!testFile}
        >
          Test File Validation
        </button>
      </div>

      {/* Test Results */}
      {Object.keys(testResults).length > 0 && (
        <div style={{ 
          background: 'var(--color-secondary)', 
          padding: '16px', 
          borderRadius: '8px',
          border: '1px solid var(--color-border)'
        }}>
          <h3 style={{ color: 'var(--color-accent)', marginBottom: '12px' }}>Test Sonuçları</h3>
          <pre style={{ 
            background: 'var(--color-background)', 
            padding: '12px', 
            borderRadius: '4px',
            overflow: 'auto',
            fontSize: '0.9em'
          }}>
            {JSON.stringify(testResults, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
