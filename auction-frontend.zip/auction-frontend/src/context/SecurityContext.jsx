import { createContext, useContext, useEffect, useState } from 'react';
import { setSecureLocalStorage, getSecureLocalStorage } from '../lib/securityUtils';

const SecurityContext = createContext();

export const useSecurity = () => {
  const context = useContext(SecurityContext);
  if (!context) {
    throw new Error('useSecurity must be used within a SecurityProvider');
  }
  return context;
};

export const SecurityProvider = ({ children }) => {
  const [securityConfig, setSecurityConfig] = useState({
    isSecure: true,
    lastActivity: Date.now(),
    sessionTimeout: 15 * 60 * 1000, // 15 dakika (canlı ortam için)
  });

  // Session timeout kontrolü
  useEffect(() => {
    const checkSession = () => {
      const now = Date.now();
      const timeSinceLastActivity = now - securityConfig.lastActivity;
      
      if (timeSinceLastActivity > securityConfig.sessionTimeout) {
        // Session timeout - kullanıcıyı logout yap
        handleSessionTimeout();
      }
    };

    const interval = setInterval(checkSession, 60000); // Her dakika kontrol et
    return () => clearInterval(interval);
  }, [securityConfig.lastActivity, securityConfig.sessionTimeout]);

  // User activity tracking
  useEffect(() => {
    const updateActivity = () => {
      setSecurityConfig(prev => ({
        ...prev,
        lastActivity: Date.now()
      }));
    };

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    events.forEach(event => {
      document.addEventListener(event, updateActivity, true);
    });

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, updateActivity, true);
      });
    };
  }, []);

  // Session timeout handler
  const handleSessionTimeout = () => {
    // Kullanıcıyı logout yap
    setSecureLocalStorage('user', null);
    setSecureLocalStorage('token', null);
    window.location.href = '/login?reason=timeout';
  };

  // Güvenlik durumu kontrolü
  const getSecurityStatus = () => {
    return {
      isSecure: securityConfig.isSecure,
      isLocked: false, // Kilitleme özelliği kaldırıldı
      sessionRemaining: Math.max(0, securityConfig.sessionTimeout - (Date.now() - securityConfig.lastActivity))
    };
  };

  // Güvenlik ayarlarını güncelle
  const updateSecurityConfig = (newConfig) => {
    setSecurityConfig(prev => ({
      ...prev,
      ...newConfig
    }));
  };

  // Context value
  const value = {
    securityConfig,
    updateSecurityConfig,
    getSecurityStatus,
    handleSessionTimeout,
  };

  return (
    <SecurityContext.Provider value={value}>
      {children}
    </SecurityContext.Provider>
  );
};
