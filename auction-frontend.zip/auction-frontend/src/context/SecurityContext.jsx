import { createContext, useContext, useEffect, useState } from 'react';
import { setSecureLocalStorage, getSecureLocalStorage } from '../lib/securityUtils';

const SecurityContext = createContext();

export const useSecurity = () => {
  const context = useContext(SecurityContext);
  if (!context) {
    throw new Error('useSecurity must be used within a SecurityProvider');
  }
  return context;
};

export const SecurityProvider = ({ children }) => {
  const [securityConfig, setSecurityConfig] = useState({
    isSecure: true,
    lastActivity: Date.now(),
    sessionTimeout: 30 * 60 * 1000, // 30 dakika
    maxLoginAttempts: 5,
    lockoutDuration: 15 * 60 * 1000, // 15 dakika
  });

  const [loginAttempts, setLoginAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const [lockoutTime, setLockoutTime] = useState(null);

  // Session timeout kontrolü
  useEffect(() => {
    const checkSession = () => {
      const now = Date.now();
      const timeSinceLastActivity = now - securityConfig.lastActivity;
      
      if (timeSinceLastActivity > securityConfig.sessionTimeout) {
        // Session timeout - kullanıcıyı logout yap
        handleSessionTimeout();
      }
    };

    const interval = setInterval(checkSession, 60000); // Her dakika kontrol et
    return () => clearInterval(interval);
  }, [securityConfig.lastActivity, securityConfig.sessionTimeout]);

  // User activity tracking
  useEffect(() => {
    const updateActivity = () => {
      setSecurityConfig(prev => ({
        ...prev,
        lastActivity: Date.now()
      }));
    };

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    events.forEach(event => {
      document.addEventListener(event, updateActivity, true);
    });

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, updateActivity, true);
      });
    };
  }, []);

  // Login attempt tracking
  const trackLoginAttempt = (success) => {
    if (success) {
      // Başarılı login - sayacı sıfırla
      setLoginAttempts(0);
      setIsLocked(false);
      setLockoutTime(null);
      setSecureLocalStorage('loginAttempts', 0);
    } else {
      // Başarısız login - sayacı artır
      const newAttempts = loginAttempts + 1;
      setLoginAttempts(newAttempts);
      setSecureLocalStorage('loginAttempts', newAttempts);

      if (newAttempts >= securityConfig.maxLoginAttempts) {
        // Hesabı kilitle
        setIsLocked(true);
        setLockoutTime(Date.now());
        setSecureLocalStorage('accountLocked', true);
        setSecureLocalStorage('lockoutTime', Date.now());
      }
    }
  };

  // Lockout kontrolü
  const checkLockout = () => {
    if (isLocked && lockoutTime) {
      const now = Date.now();
      const timeSinceLockout = now - lockoutTime;
      
      if (timeSinceLockout > securityConfig.lockoutDuration) {
        // Lockout süresi doldu
        setIsLocked(false);
        setLockoutTime(null);
        setLoginAttempts(0);
        setSecureLocalStorage('accountLocked', false);
        setSecureLocalStorage('lockoutTime', null);
        setSecureLocalStorage('loginAttempts', 0);
        return false;
      }
      return true;
    }
    return false;
  };

  // Session timeout handler
  const handleSessionTimeout = () => {
    // Kullanıcıyı logout yap
    setSecureLocalStorage('user', null);
    setSecureLocalStorage('token', null);
    window.location.href = '/login?reason=timeout';
  };

  // Güvenlik durumu kontrolü
  const getSecurityStatus = () => {
    const isLockedOut = checkLockout();
    
    return {
      isSecure: securityConfig.isSecure && !isLockedOut,
      isLocked: isLockedOut,
      remainingAttempts: Math.max(0, securityConfig.maxLoginAttempts - loginAttempts),
      lockoutRemaining: isLockedOut ? 
        Math.max(0, securityConfig.lockoutDuration - (Date.now() - lockoutTime)) : 0,
      sessionRemaining: Math.max(0, securityConfig.sessionTimeout - (Date.now() - securityConfig.lastActivity))
    };
  };

  // Güvenlik ayarlarını güncelle
  const updateSecurityConfig = (newConfig) => {
    setSecurityConfig(prev => ({
      ...prev,
      ...newConfig
    }));
  };

  // Context value
  const value = {
    securityConfig,
    updateSecurityConfig,
    trackLoginAttempt,
    checkLockout,
    getSecurityStatus,
    handleSessionTimeout,
  };

  return (
    <SecurityContext.Provider value={value}>
      {children}
    </SecurityContext.Provider>
  );
};
